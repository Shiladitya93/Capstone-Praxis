#!/usr/bin/env python
# coding: utf-8

# In[16]:


import spacy
import pickle
import pandas as pd
import numpy as np
import spacy
from scipy.stats import entropy
nlp = spacy.load("en_core_web_sm-2.2.0/")
import numpy as np
import pandas as pd
import re, nltk, spacy, gensim
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer
import flask
import flask_paginate
from flask import Flask, flash, redirect, render_template, request, session, abort,send_from_directory,send_file,url_for
from flask_paginate import Pagination, get_page_args
import pandas as pd
import numpy as np
import json
import io
import os


# In[21]:


#Create a flask application
application= flask.Flask(__name__)
application.debug = True


# In[ ]:


@application.route("/",methods=["GET","POST"])
def index():   
    if request.method == 'POST':
        messages = request.form.get('question1_field', 'Marketing')
        return flask.redirect(url_for('.profilepage', messages=messages))
    return render_template("index.html")


# In[22]:


#Create an application route
@application.route("/querypage")
def querypage():
    return render_template('QueryPage.html')


# In[23]:


@application.route('/profilepage')
def profilepage():
#Get value from post
    words = request.args['messages']  # counterpart for url_for()
    path=os.getcwd()
    df=pd.read_pickle('datafiles/InputDF.pkl')
    vectorizer = pickle.load(open('datafiles/vectorizer.pickel', 'rb'))
    best_lda_model = pickle.load(open('datafiles/BesModel.pickel','rb'))
    AlldocsProb = pickle.load(open('datafiles/Alldoc_probs.pkl', 'rb'))
    def clean_text(text):
        for ch in ['\n','                               ','\\n','.',"\'",'\\s','[]','[]','[',']','-','"','=>',':','\\uf','=','(',')','\\xa0','•','&','.',',',"'",'\uf0d6','Specialties  ','  ►','*',' ➢ ','! ','“','\uf0dc']:
            if ch in text:
                text = text.replace(ch," ")
                text=re.sub(r"\d{4}-\d{4}", '', text)
        return text
    mytext_1 = [clean_text(words)]
    def sent_to_words(sentences):
        for sentence in sentences:
            yield(gensim.utils.simple_preprocess(str(sentence), deacc=True))  # deacc=True removes punctuations
    mytext_2 = list(sent_to_words(mytext_1))
    def lemmatization(texts, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV']):
        texts_out = []
        for sent in texts:
            doc = nlp(" ".join(sent)) 
            texts_out.append(" ".join([token.lemma_ if token.lemma_ not in ['-PRON-'] else '' for token in doc if token.pos_ in allowed_postags]))
        return texts_out
    # Do lemmatization keeping only Noun, Adj, Verb, Adverb
    mytext_3 = lemmatization(mytext_2, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'])
    mytext_4 = vectorizer.transform(mytext_3)
    topic_probability_scores = best_lda_model.transform(mytext_4)
    def jensen_shannon(query, matrix):
        import numpy as np
        import scipy.stats
        p = query# take transpose
        q = matrix# transpose matrix
        m = 0.5*(p + q)
        return np.sqrt(0.5*(scipy.stats.entropy(p,m) + scipy.stats.entropy(q,m)))
    query=topic_probability_scores.ravel()
    sims=[]
    for doc in AlldocsProb:
        dist = jensen_shannon(query,doc)
        sims.append(dist)
        indices=np.argsort(sims)[:25]
    most_similar_df = df[df.index.isin(indices)]
    def summ(text):
        from gensim.summarization.textcleaner import split_sentences
        from gensim.summarization import summarize
        import re
        sen=text
    #res = len(re.findall(r'\w+',sen)) 
        split=sen.replace('.', '.\n')
        number_of_sentences = len(split_sentences(split))
        if number_of_sentences > 4:
            split =' '.join(split_sentences(split))
            new_text=summarize(split,word_count=100)
            new_text=re.sub("\n","",new_text)
            new_text=new_text.replace("*","")
            new_text=(' ').join(new_text.split())
            return new_text
        else:
            return sen
    most_similar_df['Summarized_TextV1']=most_similar_df.apply(lambda row:summ(row['Summarized_Text']),axis=1)
    data = most_similar_df.to_dict(orient = 'records')
    def get_users(offset=0, per_page=5):
        return data[offset: offset + per_page]
    page = int(request.args.get('page', 1))
    per_page = 5
    offset = (page - 1) * per_page
    total = len(data)  
    pagination_users = get_users(offset=offset, per_page=per_page)
    pagination = Pagination(page=page, per_page=per_page, total=total,css_framework='bootstrap4')                                     
    #return data to front end for display 
    return render_template('ProfilePage.html',docs=pagination_users,page=page,per_page=per_page,pagination=pagination)


# In[ ]:


if __name__ == "__main__":    
    application.run(debug=True)

